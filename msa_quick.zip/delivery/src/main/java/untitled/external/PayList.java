package untitled.external;

import java.util.Date;
import lombok.Data;

@Data
public class PayList {

    private Long id;
    private Integer price;
    private String orderId;
    // keep

}
