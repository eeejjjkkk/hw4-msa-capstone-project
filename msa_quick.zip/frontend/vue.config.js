module.exports = {
  transpileDependencies: [
    'vuetify'
  ],

  devServer: {
    disableHostCheck: true
  }
}
